globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/8k8TnfWRLTKVw3E6jWcbI/_buildManifest.js",
    "static/8k8TnfWRLTKVw3E6jWcbI/_ssgManifest.js",
    "static/8k8TnfWRLTKVw3E6jWcbI/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0k~u_jyibvj9b.js",
    "static/chunks/0hze6zhw~akeg.js",
    "static/chunks/15d4cmp.rc0z0.js",
    "static/chunks/turbopack-00f71zbv~kmea.js"
  ]
};
